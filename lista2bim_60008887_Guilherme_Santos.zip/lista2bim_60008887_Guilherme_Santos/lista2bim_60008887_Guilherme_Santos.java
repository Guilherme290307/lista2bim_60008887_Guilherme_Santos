import java.util.Scanner;
import java.util.Random;

public class lista2bim_60008887_Guilherme_Santos {

    static Scanner s = new Scanner(System.in);

    public static void main(String[] args) {

        String Opcao;

        do {
            System.out.println("\n=== MENU LISTA 2 BIM ===");
            System.out.println("A - Ordenar Inteiros");
            System.out.println("B - Imprimir Vetor de Strings");
            System.out.println("C - Ordenar Vetor");
            System.out.println("D - Soma das Linhas da Matriz");
            System.out.println("E - Transformação de Nome por Ano de Nascimento");
            System.out.println("F - Busca de Alunos (Matriz)");
            System.out.println("G - Divisão entre Vetores");
            System.out.println("H - Verificar Presença no Vetor de 50");
            System.out.println("I - Preencher Matriz 3x4 (Usuário)");
            System.out.println("J - Matriz 5x4 Aleatória");
            System.out.println("K - Conversor de Meses");
            System.out.println("L - Preço Líquido do Produto");
            System.out.println("M - Cadastro de Pedidos de Crochê");
            System.out.println("N - Função Divisão Segura");
            System.out.println("O - Média de Valores do Vetor");
            System.out.println("S - Sair");

            System.out.print("Escolha: ");
            Opcao = s.nextLine().toUpperCase();

            switch (Opcao) {
                case "A":
                    ExercicioA();
                    break;
                case "B":
                    ExercicioB();
                    break;
                case "C":
                    ExercicioC();
                    break;
                case "D":
                    ExercicioD();
                    break;
                case "E":
                    ExercicioE();
                    break;
                case "F":
                    ExercicioF();
                    break;
                case "G":
                    ExercicioG();
                    break;
                case "H":
                    ExercicioH();
                    break;
                case "I":
                    ExercicioI();
                    break;
                case "J":
                    ExercicioJ();
                    break;
                case "K":
                    ExercicioK();
                    break;
                case "L":
                    ExercicioL();
                    break;
                case "M":
                    ExercicioM();
                    break;
                case "N":
                    ExercicioN();
                    break;
                case "O":
                    ExercicioO();
                    break;

                case "S":
                    System.out.println("Encerrando...");
                    break;

                default:
                    System.out.println("Opção inválida!");
                    break;
            }

        } while (!Opcao.equals("S"));
    }

    public static void ExercicioA() {
        System.out.print("Digite três números inteiros: ");
        int A = s.nextInt();
        int B = s.nextInt();
        int C = s.nextInt();
        s.nextLine();
        int Menor = Math.min(A, Math.min(B, C));
        int Maior = Math.max(A, Math.max(B, C));
        int Meio = A + B + C - Menor - Maior;
        System.out.println("Número em ordem crescente: " + Menor + ", " + Meio + ", " + Maior + ".");
    }

    public static void ExercicioB() {
        String[][] Matriz = {
                { "Guilherme", "ADS" },
                { "João", "SI" },
                { "Ana", "Direito" }
        };
        Imprime_Vetor_String(Matriz);
    }

    public static void Imprime_Vetor_String(String[][] M) {
        for (int i = 0; i < M.length; i++) {
            for (int j = 0; j < M[i].length; j++) {
                System.out.print(M[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void ExercicioC() {
        int[] V = { 5, 3, 9, 1, 7 };
        int[] R = Ordena_Vetor(V);
        for (int x : R)
            System.out.print(x + " ");
        System.out.println();
    }

    public static int[] Ordena_Vetor(int[] V) {
        int[] R = V.clone();
        for (int i = 0; i < R.length - 1; i++) {
            for (int j = i + 1; j < R.length; j++) {
                if (R[j] < R[i]) {
                    int aux = R[i];
                    R[i] = R[j];
                    R[j] = aux;
                }
            }
        }
        return R;
    }

    public static void ExercicioD() {
        int[][] M = {
                { 1, 2, 3 },
                { 4, 5, 6 }
        };
        for (int i = 0; i < M.length; i++) {
            int Soma = 0;
            for (int j = 0; j < M[i].length; j++)
                Soma += M[i][j];
            System.out.println("Soma Linha " + i + ": " + Soma);
        }
    }

    public static void ExercicioE() {
        System.out.print("Nome: ");
        String Nome = s.nextLine();
        System.out.print("Ano Nascimento: ");
        int Ano = s.nextInt();
        s.nextLine();
        boolean Primo = true;
        if (Ano <= 1)
            Primo = false;
        else {
            for (int i = 2; i <= Math.sqrt(Ano); i++) {
                if (Ano % i == 0)
                    Primo = false;
            }
        }
        if (Primo) {
            Nome = Nome.replaceAll("[Aa]", "@");
            Nome = Nome.replaceAll("[Ee]", "!");
        } else {
            Nome = Nome.replaceAll("[Ee]", "#");
            Nome = Nome.replaceAll("[Oo]", "*");
        }
        System.out.println("Resultado: " + Nome);
    }

    public static void ExercicioF() {
        String[][] Alunos = {
                { "Guilherme Santos", "60008887" },
                { "João Silva", "123456" },
                { "Ana Pereira", "987654" }
        };
        System.out.print("Digite parte do nome: ");
        String Texto = s.nextLine().toLowerCase();

        String[][] Resultado = Busca_Aluno(Alunos, Texto);
        Imprime_Vetor_String(Resultado);
    }

    public static String[][] Busca_Aluno(String[][] Alunos, String Texto) {
        int Contador = 0;
        for (int i = 0; i < Alunos.length; i++) {
            if (Alunos[i][0].toLowerCase().contains(Texto))
                Contador++;
        }
        String[][] R = new String[Contador][2];
        int X = 0;
        for (int i = 0; i < Alunos.length; i++) {
            if (Alunos[i][0].toLowerCase().contains(Texto)) {
                R[X][0] = Alunos[i][0];
                R[X][1] = Alunos[i][1];
                X++;
            }
        }
        return R;
    }

    public static void ExercicioG() {
        int[] V1 = { 10, 20, 30, 40, 50, 60, 70, 80 };
        int[] V2 = { 2, 4, 0, 5, 10, 0, 7, 8 };
        double[] R = new double[8];

        for (int i = 0; i < 8; i++)
            R[i] = Dividir(V1[i], V2[i]);
        for (double X : R)
            System.out.print(X + " ");
        System.out.println();
    }

    public static double Dividir(double A, double B) {
        if (B == 0)
            return 0;
        return A / B;
    }

    public static void ExercicioH() {
        int[] V = new int[50];
        Random R = new Random();
        for (int i = 0; i < 50; i++)
            V[i] = R.nextInt(100) + 1;

        System.out.print("Digite um Número: ");
        int N = s.nextInt();
        s.nextLine();

        boolean Achou = false;
        for (int X : V)
            if (X == N)
                Achou = true;

        if (Achou)
            System.out.println("Está Presente");
        else
            System.out.println("Não está Presente");
    }

    public static void ExercicioI() {
        int[][] M = new int[3][4];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("Valor [" + i + "][" + j + "]: ");
                M[i][j] = s.nextInt();
            }
        }
        s.nextLine();
    }

    public static void ExercicioJ() {
        double[][] M = new double[5][4];
        Random R = new Random();
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 4; j++) {
                M[i][j] = R.nextDouble() * 100;
                System.out.print(M[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void ExercicioK() {
        System.out.print("Digite o Mês (1 a 12): ");
        int Mes = s.nextInt();
        s.nextLine();
        System.out.print("Completo ou Abreviado: ");
        String Tipo = s.nextLine();
        System.out.println(ConverterMes(Mes, Tipo));
    }

    public static String ConverterMes(int Mes, String Tipo) {
        String[] C = { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro",
                "Outubro", "Novembro", "Dezembro" };
        String[] A = { "Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez" };
        if (Mes < 1 || Mes > 12)
            return "Inválido";
        if (Tipo.equalsIgnoreCase("Completo"))
            return C[Mes - 1];
        if (Tipo.equalsIgnoreCase("Abreviado"))
            return A[Mes - 1];
        return "Inválido";
    }

    public static void ExercicioL() {
        System.out.print("Produto: ");
        String Nome = s.nextLine();
        System.out.print("Preço bruto: ");
        double Preco = s.nextDouble();
        System.out.print("Desconto (%): ");
        double Desconto = s.nextDouble();
        s.nextLine();

        double Liquido = Preco - (Preco * (Desconto / 100));
        System.out.println("Produto: " + Nome);
        System.out.println("Bruto: " + Preco);
        System.out.println("Desconto: " + Desconto + "%");
        System.out.println("Líquido: " + Liquido);
    }

    public static void ExercicioM() {
        System.out.print("Quantos pedidos Cadastrar? ");
        int Quantidade = s.nextInt();
        s.nextLine();

        String[][] Pedidos = new String[Quantidade][5];

        for (int i = 0; i < Quantidade; i++) {
            System.out.print("Número: ");
            Pedidos[i][0] = s.nextLine();
            System.out.print("Cliente: ");
            Pedidos[i][1] = s.nextLine();
            System.out.print("Cor Principal: ");
            Pedidos[i][2] = s.nextLine();
            System.out.print("Cor Secundária: ");
            Pedidos[i][3] = s.nextLine();
            System.out.print("Cor Complementar: ");
            Pedidos[i][4] = s.nextLine();
        }

        System.out.print("Buscar Pedido: ");
        String num = s.nextLine();

        boolean Achou = false;
        for (int i = 0; i < Quantidade; i++) {
            if (Pedidos[i][0].equals(num)) {
                Achou = true;
                System.out.println("Número: " + Pedidos[i][0]);
                System.out.println("Cliente: " + Pedidos[i][1]);
                System.out.println("Cor Principal: " + Pedidos[i][2]);
                System.out.println("Cor Secundária: " + Pedidos[i][3]);
                System.out.println("Cor Complementar: " + Pedidos[i][4]);
            }
        }
        if (!Achou)
            System.out.println("Pedido não Encontrado.");
    }

    public static void ExercicioN() {
        System.out.print("Digite Dividendo: ");
        double A = s.nextDouble();
        System.out.print("Digite Divisor: ");
        double B = s.nextDouble();
        s.nextLine();

        System.out.println("Resultado: " + Dividir(A, B));
    }

    public static void ExercicioO() {
        int[] numeros = preencherVetorO();
        exibirVetorO(numeros);
        double media = calcularMediaO(numeros);
        System.out.println("Média dos valores: " + media);
    }

    public static int[] preencherVetorO() {
        Random r = new Random();
        int[] vet = new int[10];
        for (int i = 0; i < vet.length; i++) {
            vet[i] = r.nextInt(100) + 1;
        }
        return vet;
    }

    public static void exibirVetorO(int[] V) {
        System.out.println("Valores do Vetor:");
        for (int N : V) {
            System.out.print(N + " ");
        }
        System.out.println();
    }

    public static double calcularMediaO(int[] V) {
        int Soma = 0;
        for (int N : V) {
            Soma += N;
        }
        return Soma / 10.0;
    }
}